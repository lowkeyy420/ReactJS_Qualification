import { Input } from "@chakra-ui/react";
import React from "react";

function SearchInput() {
  return <Input variant="filled"></Input>;
}

export default SearchInput;
